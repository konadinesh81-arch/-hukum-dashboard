const audio = document.getElementById("audio");
const playPause = document.getElementById("playPause");
const stopBtn = document.getElementById("stop");
const trackName = document.getElementById("trackName");
const trackState = document.getElementById("trackState");
const volume = document.getElementById("volume");
const volumeLabel = document.getElementById("volumeLabel");
let audioContext, sourceNode, gainNode, highShelf, presence, activeFilters = new Set();

function setupAudioGraph() {
  if (audioContext) return;
  audioContext = new (window.AudioContext || window.webkitAudioContext)();
  sourceNode = audioContext.createMediaElementSource(audio);
  gainNode = audioContext.createGain();
  highShelf = audioContext.createBiquadFilter();
  highShelf.type = "highshelf"; highShelf.frequency.value = 4500; highShelf.gain.value = 0;
  presence = audioContext.createBiquadFilter();
  presence.type = "peaking"; presence.frequency.value = 2800; presence.Q.value = 0.8; presence.gain.value = 0;
  sourceNode.connect(presence).connect(highShelf).connect(gainNode).connect(audioContext.destination);
  applyAudioSettings();
}
function applyAudioSettings() {
  if (!gainNode) return;
  const slider = Number(volume.value);
  const loudBoost = activeFilters.has("loud") ? 1.8 : 1;
  gainNode.gain.value = Math.min(10, (slider / 100) * loudBoost);
  presence.gain.value = activeFilters.has("crisp") ? 4 : 0;
  highShelf.gain.value = activeFilters.has("crisp") ? 3 : 0;
}
function setSource(src, name) {
  audio.src = src;
  trackName.textContent = name;
  trackState.textContent = "Ready to play";
  audio.load();
  setupAudioGraph();
  if (audioContext.state === "suspended") audioContext.resume();
  audio.play().then(() => { playPause.textContent = "Ⅱ"; trackState.textContent = "Playing"; })
    .catch(() => { trackState.textContent = "Press play to start"; });
}
document.getElementById("loadUrl").addEventListener("click", () => {
  const value = document.getElementById("audioUrl").value.trim();
  try {
    const parsed = new URL(value);
    if (!["http:", "https:"].includes(parsed.protocol)) throw new Error();
    setSource(value, parsed.pathname.split("/").pop() || "Audio URL");
  } catch { alert("Enter a valid http/https direct audio URL."); }
});
document.getElementById("playPause").addEventListener("click", async () => {
  if (!audio.src) return;
  setupAudioGraph();
  if (audioContext.state === "suspended") await audioContext.resume();
  if (audio.paused) { await audio.play(); playPause.textContent = "Ⅱ"; }
  else { audio.pause(); playPause.textContent = "▶"; }
});
stopBtn.addEventListener("click", () => { audio.pause(); audio.currentTime = 0; playPause.textContent = "▶"; });
audio.addEventListener("ended", () => { playPause.textContent = "▶"; trackState.textContent = "Finished"; });
volume.addEventListener("input", () => {
  volumeLabel.textContent = volume.value + (Number(volume.value) <= 100 ? "%" : " / 1000");
  setupAudioGraph(); applyAudioSettings();
});
document.querySelectorAll(".filter").forEach(button => {
  button.addEventListener("click", () => {
    const name = button.dataset.filter;
    if (activeFilters.has(name)) { activeFilters.delete(name); button.classList.remove("active"); }
    else { activeFilters.add(name); button.classList.add("active"); }
    setupAudioGraph(); applyAudioSettings();
  });
});