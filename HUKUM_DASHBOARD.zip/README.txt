HUKUM DASHBOARD — Replit starter

1. Create a new Replit Python project.
2. Upload these files preserving the folder structure.
3. In Replit Secrets add:
   FLASK_SECRET_KEY = a long random secret
   USER_USERNAME = DINESH
   USER_PASSWORD = DINESH
   ADMIN_USERNAME = HUKUM
   ADMIN_PASSWORD = HUKM 163
4. Install dependencies: pip install -r requirements.txt
5. Run: python app.py
6. Open the Replit web preview.

Important:
- This starter has login, file upload, browser audio playback, URL playback, and browser-side audio effects.
- It does NOT join Discord voice channels or manage Discord bots. Real Discord VC playback needs an official Discord bot and a separate server-side voice integration.
- Do not use personal Discord account tokens. Never expose bot tokens in frontend code.
- Change the demo passwords before publishing publicly.
- Uploaded audio is stored in the Replit app's uploads folder; consider storage limits and moderation before public use.

7. Discord Bot Token:
   - Sign in using the ADMIN account.
   - Open Discord Setup / Bot Token Settings.
   - Paste your official bot token and choose SAVE / UPDATE TOKEN.
   - The token is stored server-side in instance/discord_bot_token.txt with restricted file permissions.
   - The dashboard never displays the saved token again. Use REMOVE SAVED TOKEN to delete it.
   - This feature stores the token only; it does not yet run the Discord bot or connect to voice.
   - For production, use Replit Secrets (DISCORD_BOT_TOKEN) and a dedicated bot process. Never commit token files to Git or share the token.
