import os
import secrets
from functools import wraps
from urllib.parse import urlparse

from flask import Flask, render_template, request, redirect, url_for, session, flash, send_from_directory
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY") or secrets.token_hex(32)
app.config["MAX_CONTENT_LENGTH"] = 25 * 1024 * 1024
app.config["UPLOAD_FOLDER"] = os.path.join(app.root_path, "uploads")

ALLOWED_EXTENSIONS = {"mp3", "wav", "ogg", "m4a", "aac", "flac"}

# Set these in Replit Secrets. These are demo credentials; change them before public deployment.
ACCOUNTS = {
    "USER": {
        "username": os.environ.get("USER_USERNAME", "DINESH"),
        "password": os.environ.get("USER_PASSWORD", "DINESH"),
        "role": "USER",
    },
    "ADMIN": {
        "username": os.environ.get("ADMIN_USERNAME", "HUKUM"),
        "password": os.environ.get("ADMIN_PASSWORD", "HUKM 163"),
        "role": "ADMIN",
    },
}

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if "role" not in session:
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        selected_role = request.form.get("role", "").upper()
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        account = ACCOUNTS.get(selected_role)
        if account and secrets.compare_digest(username, account["username"]) and secrets.compare_digest(password, account["password"]):
            session.clear()
            session["username"] = account["username"]
            session["role"] = account["role"]
            return redirect(url_for("dashboard"))
        flash("Invalid role, username, or password.", "error")
    if "role" in session:
        return redirect(url_for("dashboard"))
    return render_template("login.html")

@app.route("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html", username=session["username"], role=session["role"])

@app.route("/upload", methods=["POST"])
@login_required
def upload():
    file = request.files.get("audio_file")
    if not file or not file.filename:
        flash("Choose an audio file first.", "error")
        return redirect(url_for("dashboard"))
    filename = secure_filename(file.filename)
    if not allowed_file(filename):
        flash("Allowed formats: MP3, WAV, OGG, M4A, AAC, FLAC.", "error")
        return redirect(url_for("dashboard"))
    # Random prefix avoids filename collisions.
    safe_name = secrets.token_hex(8) + "_" + filename
    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
    file.save(os.path.join(app.config["UPLOAD_FOLDER"], safe_name))
    return redirect(url_for("play_upload", filename=safe_name))

@app.route("/uploads/<path:filename>")
@login_required
def play_upload(filename):
    return send_from_directory(app.config["UPLOAD_FOLDER"], filename, as_attachment=False)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.errorhandler(413)
def too_large(_error):
    flash("File too large. Maximum upload size is 25 MB.", "error")
    return redirect(url_for("dashboard"))

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "3000"))
    app.run(host="0.0.0.0", port=port, debug=False)