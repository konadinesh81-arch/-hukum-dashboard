HUKUM DASHBOARD — Replit starter

1. Create a new Replit Python project.
2. Upload these files preserving the folder structure.
3. In Replit Secrets add:
   FLASK_SECRET_KEY = a long random secret
   USER_USERNAME = DINESH
   USER_PASSWORD = DINESH
   ADMIN_USERNAME = HUKUM
   ADMIN_PASSWORD = HUKM 163
4. Install dependencies: pip install -r requirements.txt
5. Run: python app.py
6. Open the Replit web preview.

Important:
- This starter has login, file upload, browser audio playback, URL playback, and browser-side audio effects.
- It does NOT join Discord voice channels or manage Discord bots. Real Discord VC playback needs an official Discord bot and a separate server-side voice integration.
- Do not use personal Discord account tokens. Never expose bot tokens in frontend code.
- Change the demo passwords before publishing publicly.
- Uploaded audio is stored in the Replit app's uploads folder; consider storage limits and moderation before public use.
